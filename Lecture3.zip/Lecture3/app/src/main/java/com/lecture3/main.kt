package com.lecture3

fun main() {
    val f1 = Figure(1, 9) // 9
    val f2 = Figure(8, 2) // 16
    val f3 = Figure(6, 4) // 24
    val figures = listOf(f1, f2, f3)

    var sumOfAreas = 0

    figures.forEach {
        sumOfAreas += it.area
    }

    println("Sum of areas = $sumOfAreas\n")

    val r1 = Shape.Rectangle(6, 3)
    val r2 = Shape.Rectangle(7, 5)
    val r3 = Shape.Rectangle(4, 7)
    val c1 = Shape.Circle(9)
    val c2 = Shape.Circle(11)
    val l = Shape.Line(12)
    val o = Shape.Oval(2, 5)

    val shapes = mutableListOf(r1, r2, r3, c1, c2, o, l)

    var rectangles = shapes.filterIsInstance<Shape.Rectangle>().count()
    var circles = shapes.filterIsInstance<Shape.Circle>().count()
    var lines = shapes.filterIsInstance<Shape.Line>().count()
    var ovals = shapes.filterIsInstance<Shape.Oval>().count()

    println("Number of rectangles: $rectangles")
    println("Number of circles: $circles")
    println("Number of lines: $lines")
    println("Number of ovals: $ovals")

    rectangles = 0
    circles = 0
    lines = 0
    ovals = 0

    shapes.forEach {
        when(it) {
            is Shape.Rectangle -> rectangles++
            is Shape.Circle -> circles++
            is Shape.Oval -> ovals++
            is Shape.Line -> lines++
        }
    }

    println("\nNumber of rectangles: $rectangles")
    println("Number of circles: $circles")
    println("Number of lines: $lines")
    println("Number of ovals: $ovals")
}