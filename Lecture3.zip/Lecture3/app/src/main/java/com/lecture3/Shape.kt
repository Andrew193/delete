package com.lecture3

sealed interface Shape {
    class Rectangle(sideX: Int, sideY: Int): Shape
    class Line(length: Int): Shape

    sealed class Ellipse: Shape

    class Circle(radius: Int) : Ellipse()
    class Oval(radiusSmall: Int, radiusLarge: Int) : Ellipse()

}